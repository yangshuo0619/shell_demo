#!/bin/bash

/bin/bash /usr/bin/rosbag_record.sh &
/bin/bash /usr/bin/check_file_time.sh

