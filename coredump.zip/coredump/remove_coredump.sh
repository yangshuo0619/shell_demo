#!/bin/bash

sudo crontab -l > conf && sed -i '/core_dump.sh/d' conf && sudo crontab conf && sudo rm -f conf

sudo rm -rf /usr/bin/core_dump.sh

if [ $? -eq 0 ];
then
        echo -e "\033[42;37m********coredump************remove***********success*********\033[0m"
else
        echo -e "\033[41;37m!!!!!!!!coredump!!!!!!!!!!!!!remove!!!!!!!!!!!failed!!!!!!!!!\033[0m"
fi

