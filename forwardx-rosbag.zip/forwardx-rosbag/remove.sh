#!/bin/bash

sudo rm /usr/bin/forwardx_rosbag.sh
sudo rm /usr/bin/check_file_time.sh
sudo rm /usr/bin/rosbag_record.sh

sudo systemctl stop forwardx-rosbag.service

sudo systemctl disable forwardx-rosbag.service

sudo systemctl daemon-reload

sudo rm /etc/systemd/system/forwardx-rosbag.service
bag_file="/home/ld/ros_bag"
sudo rm -rf "${bag_file}"

