# install forwardx-rosbag service
$ sudo bash install.sh

# remove forwardx-rosbag service
$ sudo bash remove.sh

# check forwardx-bag service status
$ sudo service forwardx-rosbag status

# ros bag file path
$ /home/ld/ros_bag

# modify rosbag topic

1. $ sudo vim /usr/bin/rosbag_record.sh
2. $ sudo service forwardx-rosbag stop
3. $ sudo service forwardx-rosbag start

# modify rosbag time, dafault time 1 hours.

1. $ sudo vim /usr/bin/check_file_time.sh
2. $ sudo service forwardx-rosbag stop
3. $ sudo service forwardx-rosbag start

