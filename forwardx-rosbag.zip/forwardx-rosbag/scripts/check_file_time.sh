#!/bin/bash

bag_file="/home/ld/ros_bag/"

#ls "${bag_file}" | awk -F "_" '{ if( $1 < "'$str_time'")  print "rm " $0}' 

while true
do
    str_time=$(date -d "1 hour ago" +"%Y-%m-%d-%H-%M-%S")
    ls "${bag_file}" | awk -F "_" '{ if( $1 < "'$str_time'")  print "rm '$bag_file'" $0}' | sh
    sleep 60s
done
 


