#!/bin/bash

CURRENT_DIR=$(cd $(dirname ${BASH_SOURCE[0]}); pwd)
cd "${CURRENT_DIR}"

sudo cp core_dump.sh /usr/bin
sudo chmod a+x /usr/bin/core_dump.sh

sudo crontab -l > /dev/null 2>&1
if [ $? -eq 0 ];
then
  sudo crontab -l > conf && sudo echo " */60 * * * * bash /usr/bin/core_dump.sh > /dev/null 2>&1 " >> conf && sudo crontab conf && sudo rm -f conf
else
  sudo echo " */60 * * * * bash /usr/bin/core_dump.sh > /dev/null 2>&1 " >> conf && sudo crontab conf && sudo rm -f conf
fi

if [ $? -eq 0 ];
then
        echo -e "\033[42;37m********coredump************setting***********success*********\033[0m"
else
        echo -e "\033[41;37m!!!!!!!!coredump!!!!!!!!!!!!!setting!!!!!!!!!!!failed!!!!!!!!!\033[0m"
fi

