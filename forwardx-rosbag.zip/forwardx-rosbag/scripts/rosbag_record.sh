#!/bin/bash 

source /opt/ros/kinetic/setup.bash
source /opt/raccoon/setup.bash

bag_file="/home/ld/ros_bag"

cd "${bag_file}"

rosbag record --split --duration=30m /tf /tf_static /scan

