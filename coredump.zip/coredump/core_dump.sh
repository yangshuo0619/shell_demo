#!/bin/bash

CORE_DIR="/opt/raccoon/share"
CORE_DUMP_LIST_FILE="/var/log/forwardx/core_dump_list.log"
CORE_DUMP_INFO_FILE="/var/log/forwardx/core_dump_info.log"
CORE_DUMP_LIST_FILE_BACKUP="/var/log/forwardx/core_dump_list.log.1"
CORE_DUMP_INFO_FILE_BACKUP="/var/log/forwardx/core_dump_info.log.1"

check_log_file()
{
  if [ ! -f ${CORE_DUMP_LIST_FILE} ];
  then
    touch ${CORE_DUMP_LIST_FILE}
    touch ${CORE_DUMP_INFO_FILE}
  else
    log_file_size=$(ls -l ${CORE_DUMP_INFO_FILE} | awk '{print $5}')
    max_size=$((1024*1024*10))
    if [ ${log_file_size} -gt ${max_size} ];
    then
      mv ${CORE_DUMP_INFO_FILE} ${CORE_DUMP_INFO_FILE_BACKUP} 
      mv ${CORE_DUMP_LIST_FILE} ${CORE_DUMP_LIST_FILE_BACKUP} 
    fi
  fi

}

check_core_file()
{
  cd ${CORE_DIR}

  cur_core_list=$(ls -l --time-style=long-iso | grep "core-" | awk -F " " '{print $5"#"$6"-"$7"#"$8}')
  
  for item in ${cur_core_list[*]}
  do
    count=$(grep ${item} ${CORE_DUMP_LIST_FILE} -c)
    if [ ${count} -eq 0 ];
    then
      get_core_info ${item}
    fi

  done

}

get_core_info()
{
  echo $1 >> ${CORE_DUMP_LIST_FILE}
  echo "====================================================================================" >> ${CORE_DUMP_INFO_FILE}
  echo $1 >> ${CORE_DUMP_INFO_FILE}
  core_file_name=$( echo $1 | awk -F "#" '{print $3}')
  core_file_full_name="${CORE_DIR}/${core_file_name}"
  exe_cmd=$(file ${core_file_full_name} | awk -F " " '{print $13}' | sed $'s/\'//g')
  echo ${core_file_full_name} >> ${CORE_DUMP_INFO_FILE}
  echo ${exe_cmd} | awk -F "/" '{print "dpkg -l | grep raccoon | grep " $5}' | sed $'s/\_/-/g' | sh | awk '{print $2 " " $3}'  >> ${CORE_DUMP_INFO_FILE} 2>&1
  echo ${exe_cmd} >> ${CORE_DUMP_INFO_FILE}
  gdb -q --batch --ex "set height 0" -ex "bt full" ${exe_cmd} ${core_file_full_name} >> ${CORE_DUMP_INFO_FILE} 2>&1
  echo "====================================================================================" >> ${CORE_DUMP_INFO_FILE}
}

check_log_file
check_core_file
