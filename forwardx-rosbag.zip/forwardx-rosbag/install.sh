#!/bin/bash

sudo cp ./scripts/forwardx_rosbag.sh /usr/bin/
sudo cp ./scripts/check_file_time.sh /usr/bin/
sudo cp ./scripts/rosbag_record.sh /usr/bin/

bag_file="/home/ld/ros_bag"
sudo mkdir -p "${bag_file}"

sudo cp ./forwardx-rosbag.service /etc/systemd/system/

sudo systemctl enable forwardx-rosbag.service

sudo systemctl daemon-reload

sudo systemctl start forwardx-rosbag.service

